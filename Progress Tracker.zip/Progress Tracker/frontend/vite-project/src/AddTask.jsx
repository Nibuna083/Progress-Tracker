import React, { useState, useEffect } from "react";
import axios from "axios";
import ViewTask from "./ViewTask";
import './styles/Stats.css';

function AddTask() {
    const [task, setTask] = useState("");
    const [scheduledTime, setScheduledTime] = useState("");
    const [data, setData] = useState([]);
    const [overallStats, setOverallStats] = useState({
        completed: 0,
        aborted: 0,
        efficiency: 0
    });

    async function fetchData() {
        try {
            const response = await axios.get("http://localhost:3000/api/v1/todo");
            setData(response.data);
            
            // Calculate overall statistics
            const stats = response.data.reduce((acc, task) => {
                if (task.status === 'completed') acc.completed++;
                if (task.status === 'aborted') acc.aborted++;
                return acc;
            }, { completed: 0, aborted: 0 });
            
            const totalTasks = stats.completed + stats.aborted;
            const efficiency = totalTasks > 0 
                ? Math.round((stats.completed / totalTasks) * 100)
                : 0;
            
            setOverallStats({
                ...stats,
                efficiency
            });
        } catch (error) {
            console.error("Error fetching tasks:", error);
        }
    }

    useEffect(() => {
        fetchData();
        const interval = setInterval(fetchData, 30000); 
        return () => clearInterval(interval);
    }, []);

    async function handleSubmit(e) {
        e.preventDefault();
        if (task.trim() && scheduledTime) {
            try {
                await axios.post("http://localhost:3000/api/v1/todo", {
                    task: task,
                    scheduledTime: new Date(scheduledTime),
                    status: 'pending'
                });
                await fetchData();
                setTask("");
                setScheduledTime("");
            } catch (error) {
                console.error("Error creating task:", error);
            }
        }
    }

    async function handleStatusUpdate(taskId, status, estimatedTime = null) {
        try {
            const updateData = {
                status: status,
                startTime: status === 'in-progress' ? new Date() : null,
                completionTime: ['completed', 'aborted'].includes(status) ? new Date() : null,
                estimatedTime: estimatedTime
            };
            
            await axios.put(`http://localhost:3000/api/v1/todo/${taskId}`, updateData);
            await fetchData();
        } catch (error) {
            console.error("Error updating task status:", error);
        }
    }

    return (
        <div className="todo-container">
            <form onSubmit={handleSubmit} className="add-task-form">
                <input
                    type="text"
                    placeholder="Add a new task"
                    value={task}
                    onChange={(e) => setTask(e.target.value)}
                />
                <input
                    type="datetime-local"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                />
                <button type="submit">Add Task</button>
            </form>
            
            <div className="tasks-list">
                {data.map((task) => (
                    <ViewTask
                        key={task._id}
                        task={task}
                        onStatusUpdate={handleStatusUpdate}
                        onUpdate={fetchData}
                    />
                ))}
            </div>

            <div className="overall-stats">
                <h3>Overall Performance</h3>
                <div className="stats-grid">
                    <div className="stat-item">
                        <span className="stat-label">Completed Tasks:</span>
                        <span className="stat-value">{overallStats.completed}</span>
                    </div>
                    <div className="stat-item">
                        <span className="stat-label">Aborted Tasks:</span>
                        <span className="stat-value">{overallStats.aborted}</span>
                    </div>
                    <div className="stat-item efficiency">
                        <span className="stat-label">Overall Efficiency:</span>
                        <span className={`stat-value ${overallStats.efficiency >= 70 ? 'high' : overallStats.efficiency >= 40 ? 'medium' : 'low'}`}>
                            {overallStats.efficiency}%
                        </span>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AddTask;