import { useState } from 'react'
import AddTask from './addTask'
import './App.css'

function App() {
  return (
    <div className="app-container">
      <h1 className='header' style={{position:'relative', left:'450px'}}>Progress Tracker</h1>
      <div className="container">
        <AddTask/>
      </div>
    </div>
  )
}

export default App
