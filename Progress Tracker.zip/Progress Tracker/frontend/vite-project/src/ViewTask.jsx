import React, { useState, useEffect } from 'react';
import axios from "axios";

function ViewTask({ task, onStatusUpdate, onUpdate }) {
    const [isEditing, setIsEditing] = useState(false);
    const [editedTask, setEditedTask] = useState(task.task);
    const [countdown, setCountdown] = useState(null);
    const [timer, setTimer] = useState(null);

    // Initialize timer if task is in-progress
    useEffect(() => {
        if (task.status === 'in-progress' && task.estimatedTime && !timer) {
            const startTime = new Date(task.startTime);
            const totalSeconds = task.estimatedTime * 60;
            const elapsedSeconds = Math.floor((new Date() - startTime) / 1000);
            const remainingSeconds = Math.max(0, totalSeconds - elapsedSeconds);
            
            if (remainingSeconds > 0) {
                setCountdown(remainingSeconds);
                const timerInterval = setInterval(() => {
                    setCountdown(prev => {
                        if (prev <= 1) {
                            clearInterval(timerInterval);
                            return 0;
                        }
                        return prev - 1;
                    });
                }, 1000);
                setTimer(timerInterval);
            } else {
                handleTimerComplete();
            }
        }
    }, [task.status, task.estimatedTime]);

    // Cleanup timer on unmount or status change
    useEffect(() => {
        return () => {
            if (timer) {
                clearInterval(timer);
            }
        };
    }, [timer]);

    // Handle timer completion
    useEffect(() => {
        if (countdown === 0 && task.status === 'in-progress') {
            handleTimerComplete();
        }
    }, [countdown]);

    async function handleTimerComplete() {
        if (timer) {
            clearInterval(timer);
            setTimer(null);
        }
        
        if (task.status === 'in-progress') {
            const userChoice = window.confirm(
                `Time's up for task: ${task.task}!\n\n` +
                'Click OK to mark as Completed, or Cancel to mark as Aborted'
            );
            
            await handleStatusChange(userChoice ? 'completed' : 'aborted');
        }
    }

    async function handleDelete() {
        try {
            await axios.delete(`http://localhost:3000/api/v1/todo/${task._id}`);
            onUpdate();
        } catch (error) {
            console.error("Error deleting task:", error);
        }
    }

    async function handleEdit() {
        try {
            await axios.put(`http://localhost:3000/api/v1/todo/${task._id}`, {
                task: editedTask
            });
            setIsEditing(false);
            onUpdate();
        } catch (error) {
            console.error("Error updating task:", error);
        }
    }

    async function handleStatusChange(status) {
        try {
            if (status === 'in-progress') {
                const estimate = prompt('Enter approximate time in minutes for this task:');
                if (!estimate || isNaN(estimate) || estimate <= 0) {
                    alert('Please enter a valid time in minutes');
                    return;
                }

                const estimatedMinutes = parseInt(estimate);
                setCountdown(estimatedMinutes * 60);
                
                const timerInterval = setInterval(() => {
                    setCountdown(prev => {
                        if (prev <= 1) {
                            clearInterval(timerInterval);
                            return 0;
                        }
                        return prev - 1;
                    });
                }, 1000);
                
                setTimer(timerInterval);
                await onStatusUpdate(task._id, status, estimatedMinutes);
            } else {
                if (timer) {
                    clearInterval(timer);
                    setTimer(null);
                }
                setCountdown(null);
                await onStatusUpdate(task._id, status);
            }
        } catch (error) {
            console.error("Error updating status:", error);
            alert("Error updating task status. Please try again.");
        }
    }

    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }

    return (
        <div className="task-item">
            {isEditing ? (
                <div className="edit-form">
                    <input
                        type="text"
                        value={editedTask}
                        onChange={(e) => setEditedTask(e.target.value)}
                        className="edit-input"
                    />
                    <button onClick={handleEdit} className="save-btn">Save</button>
                    <button onClick={() => setIsEditing(false)} className="cancel-btn">Cancel</button>
                </div>
            ) : (
                <div className="task-content">
                    <div className="task-header">
                        <h3>{task.task}</h3>
                        <span className="scheduled-time">
                            Scheduled: {new Date(task.scheduledTime).toLocaleString()}
                        </span>
                    </div>
                    
                    {countdown !== null && task.status === 'in-progress' && (
                        <div className={`timer ${countdown <= 60 ? 'timer-warning' : ''}`}>
                            Time remaining: {formatTime(countdown)}
                        </div>
                    )}
                    
                    <div className="task-status">
                        Status: <span className={`status-${task.status}`}>{task.status}</span>
                        {task.efficiency !== null && (
                            <span className="efficiency">
                                (Efficiency: {task.efficiency}%)
                            </span>
                        )}
                    </div>

                    <div className="task-actions">
                        <button onClick={() => setIsEditing(true)} className="edit-btn">Edit</button>
                        <button onClick={handleDelete} className="delete-btn">Delete</button>
                        
                        {task.status === 'pending' && (
                            <button 
                                onClick={() => handleStatusChange('in-progress')}
                                className="start-btn"
                            >
                                Start
                            </button>
                        )}
                        
                        {task.status === 'in-progress' && (
                            <>
                                <button 
                                    onClick={() => handleStatusChange('completed')}
                                    className="complete-btn"
                                >
                                    Complete
                                </button>
                                <button 
                                    onClick={() => handleStatusChange('aborted')}
                                    className="abort-btn"
                                >
                                    Abort
                                </button>
                            </>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default ViewTask;