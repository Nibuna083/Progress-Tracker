const express = require('express');
const http = require("http");
const path = require("path");
const app = express();
const db = require('./DB/db');
const cors = require('cors');
const todoSchema = require('./model/schema');

app.use(cors());
app.use(express.json());

let isDbConnected = false;

async function connectDB() {
    try {
        await db();
        isDbConnected = true;
        console.log('Database connected successfully');
    } catch (error) {
        console.error('Failed to connect to database:', error);
        isDbConnected = false;
    }
}

connectDB();

app.use((req, res, next) => {
    if (!isDbConnected) {
        return res.status(503).json({ 
            error: "Database not connected",
            message: "Please try again in a few moments"
        });
    }
    next();
});

app.get("/api/v1/todo", async (req, res) => {
    try {
        const tasks = await todoSchema.find().sort({ scheduledTime: 1 });
        res.json(tasks);
    } catch (error) {
        console.error('Error fetching tasks:', error);
        res.status(500).json({ 
            error: "Error fetching tasks",
            message: error.message
        });
    }
});

app.post("/api/v1/todo", async (req, res) => {
    try {
        const { task, scheduledTime } = req.body;
        
        if (!task || !scheduledTime) {
            return res.status(400).json({ 
                error: "Missing required fields",
                required: { task: "string", scheduledTime: "date" },
                received: req.body 
            });
        }

        const newTask = new todoSchema({
            task,
            scheduledTime: new Date(scheduledTime),
            status: 'pending',
            efficiency: 100
        });

        await newTask.save();
        console.log('Task created:', newTask);
        res.status(201).json(newTask);
    } catch (error) {
        console.error('Error creating task:', error);
        res.status(500).json({ 
            error: "Error creating task",
            message: error.message,
            details: error.errors ? Object.values(error.errors).map(err => err.message) : undefined
        });
    }
});

app.put("/api/v1/todo/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const updates = req.body;
        
        // If status is changing to in-progress, set startTime
        if (updates.status === 'in-progress') {
            updates.startTime = new Date();
        }
        
        // If status is changing to completed or aborted, set completionTime
        if (updates.status === 'completed' || updates.status === 'aborted') {
            updates.completionTime = new Date();
            
            // Calculate efficiency if task is completed
            if (updates.status === 'completed' && updates.estimatedTime) {
                const task = await todoSchema.findById(id);
                const startTime = task.startTime || task.scheduledTime;
                const duration = (new Date() - new Date(startTime)) / (1000 * 60); // Duration in minutes
                updates.efficiency = Math.round((updates.estimatedTime / duration) * 100);
            }
        }
        
        const updatedTask = await todoSchema.findByIdAndUpdate(
            id,
            updates,
            { new: true, runValidators: true }
        );
        
        if (!updatedTask) {
            return res.status(404).json({ error: "Task not found" });
        }
        
        res.json(updatedTask);
    } catch (error) {
        console.error('Error updating task:', error);
        res.status(500).json({ 
            error: "Error updating task",
            message: error.message 
        });
    }
});

app.put("/api/v1/todo/:id/status", async (req, res) => {
    try {
        const id = req.params.id;
        const { status } = req.body;
        
        if (!['pending', 'ongoing', 'completed', 'stopped'].includes(status)) {
            return res.status(400).json({ 
                error: "Invalid status",
                message: "Status must be one of: pending, ongoing, completed, stopped"
            });
        }

        const now = new Date();
        let updateData = { status };
        
        if (status === 'ongoing') {
            updateData.startTime = now;
        } else if (status === 'completed' || status === 'stopped') {
            updateData.endTime = now;
            
            const task = await todoSchema.findById(id);
            if (!task) {
                return res.status(404).json({ error: "Task not found" });
            }
            
            const scheduledTime = new Date(task.scheduledTime);
            const startTime = new Date(task.startTime);
            const actualDuration = now - startTime;
            const scheduledDuration = startTime - scheduledTime;
            
            let efficiency = 100;
            if (status === 'completed') {
                efficiency = Math.round((scheduledDuration / actualDuration) * 100);
            } else if (status === 'stopped') {
                efficiency = Math.max(0, efficiency - 25);
            }
            
            updateData.efficiency = efficiency;
        }
        
        const updatedTask = await todoSchema.findByIdAndUpdate(
            id,
            updateData,
            { new: true, runValidators: true }
        );
        
        if (!updatedTask) {
            return res.status(404).json({ error: "Task not found" });
        }
        
        res.json(updatedTask);
    } catch (error) {
        console.error('Error updating task status:', error);
        res.status(500).json({ 
            error: "Error updating task status",
            message: error.message
        });
    }
});

app.delete("/api/v1/todo/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const deletedTask = await todoSchema.findByIdAndDelete(id);
        
        if (!deletedTask) {
            return res.status(404).json({ error: "Task not found" });
        }
        
        res.json({ message: "Task deleted successfully" });
    } catch (error) {
        console.error('Error deleting task:', error);
        res.status(500).json({ 
            error: "Error deleting task",
            message: error.message
        });
    }
});

const PORT = process.env.PORT || 3000;

// Start server
const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// Handle server errors
server.on('error', (error) => {
    console.error('Server error:', error);
    if (error.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} is already in use`);
        process.exit(1);
    }
}); 