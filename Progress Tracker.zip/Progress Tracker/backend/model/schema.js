const mongoose = require('mongoose');

const todoSchema = new mongoose.Schema({
    task: {
        type: String,
        required: true
    },
    scheduledTime: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        enum: ['pending', 'in-progress', 'completed', 'aborted'],
        default: 'pending'
    },
    startTime: {
        type: Date,
        default: null
    },
    completionTime: {
        type: Date,
        default: null
    },
    estimatedTime: {
        type: Number,
        default: null
    },
    efficiency: {
        type: Number,
        min: 0,
        max: 100,
        default: null
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Todo', todoSchema);